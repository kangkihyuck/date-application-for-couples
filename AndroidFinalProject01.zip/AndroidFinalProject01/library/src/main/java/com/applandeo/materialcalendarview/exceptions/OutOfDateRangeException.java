package com.applandeo.materialcalendarview.exceptions;



public class OutOfDateRangeException extends Exception {
    public OutOfDateRangeException(String message) {
        super(message);
    }
}
