package com.applandeo.materialcalendarview.exceptions;



public class UnsupportedMethodsException extends RuntimeException {
    public UnsupportedMethodsException(String message) {
        super(message);
    }
}
