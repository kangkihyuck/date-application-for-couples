package com.applandeo.materialcalendarview.listeners;



public interface OnCalendarPageChangeListener {
    void onChange();
}
