package com.applandeo.materialcalendarview.listeners;

import com.applandeo.materialcalendarview.EventDay;



public interface OnDayClickListener {
    void onDayClick(EventDay eventDay);
}
