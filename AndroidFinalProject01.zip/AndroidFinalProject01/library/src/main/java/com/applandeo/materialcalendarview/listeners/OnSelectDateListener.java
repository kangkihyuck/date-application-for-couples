package com.applandeo.materialcalendarview.listeners;

import java.util.Calendar;
import java.util.List;



public interface OnSelectDateListener {
    void onSelect(List<Calendar> calendar);
}
