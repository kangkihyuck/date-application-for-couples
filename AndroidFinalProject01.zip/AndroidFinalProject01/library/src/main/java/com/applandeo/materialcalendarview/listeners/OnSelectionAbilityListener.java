package com.applandeo.materialcalendarview.listeners;



public interface OnSelectionAbilityListener {
    void onChange(boolean enabled);
}
