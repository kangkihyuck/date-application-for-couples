package com.applandeo.materialcalendarsampleapp

class CultureDTO {
    var culture_accomcountculture = ""
    var culture_chkcreditcardculture =""
    var culture_discountinfo = ""
    var culture_parkingculture = ""
    var culture_spendtime = ""
    var culture_usetimeculture = ""
    var culture_usefee = ""
    var culture_restdateculture = ""
}