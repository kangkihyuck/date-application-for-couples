package com.applandeo.materialcalendarsampleapp

class DestinationDTO {
    var destination_expguide = ""
    var destination_parking = ""
    var destination_restdate = ""
    var destination_usetime = ""
    var destination_chkcreditcard = ""
}