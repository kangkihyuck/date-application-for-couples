package com.applandeo.materialcalendarsampleapp

class FestivalDTO {
    var festival_agelimit = ""
    var festival_bookingplace = ""
    var festival_discountinfofestival = ""
    var festival_usetimefestival = ""
    var festival_eventstartdate = ""
    var festival_eventenddate = ""
    var festival_eventplace = ""
    var festival_placeinfo = ""
    var festival_playtime = ""
    var festival_spendtimefestival = ""
    var festival_program = ""
    var festival_subevent = ""
    var festival_eventhomepage = ""
}