package com.applandeo.materialcalendarsampleapp

class ListViewItem {

    var mcvdate1: String? = null
    var mcvcontent1: String? = null
    var mcvsysdate1: String? = null

}