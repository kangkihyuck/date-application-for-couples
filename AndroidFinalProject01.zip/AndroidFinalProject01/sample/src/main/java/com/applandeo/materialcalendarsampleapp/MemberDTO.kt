package com.applandeo.materialcalendarsampleapp

class MemberDTO {
    var MEMBER_KEY : Int = 0
    var MEMBER_ID : String = ""
    var MEMBER_PW : String = ""
    var MEMBER_NAME : String = ""
    var MEMBER_DATE : String = ""
    var MEMBER_PHONE : Int = 0
    var MEMBER_EMAIL : String = ""
    var MEMBER_GENDER : Int = 0
    var MEMBER_USE : Int = 0
    var MEMBER_STARTDATE : String = ""
    var MEMBER_DELETEDATE : String = ""
    var MEMBER_GRADE : Int = 0
}