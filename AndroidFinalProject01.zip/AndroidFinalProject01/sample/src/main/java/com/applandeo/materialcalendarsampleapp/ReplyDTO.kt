package com.applandeo.materialcalendarsampleapp


class ReplyDTO {
    var reply_contentid = ""
    var member_id = ""
    var reply_title = ""
    var reply_reply = ""
    var reply_score = ""
    var reply_date = ""
}