package com.applandeo.materialcalendarsampleapp

class ShoppingDTO {
    var shopping_chkbabycarriageshopping = ""
    var shopping_infocentershopping =""
    var shopping_opentime =""
    var shopping_parkingshopping = ""
    var shopping_restdateshopping =""
    var shopping_saleitem = ""
}